import json
import dataiku
import io
import requests
from requests.auth import HTTPBasicAuth
from dataiku.customrecipe import get_recipe_config, get_output_names_for_role
from dataikuapi.utils import DataikuException
 
# Create a client to access the Dataiku instance
client = dataiku.api_client()
# list the project keys for which you have access
project_keys = client.list_project_keys()
print('List of project IDs are:', project_keys)

print('''
===========================================\n
PROJECT INFORMATION (JSON)\n
===========================================\n''')

try:
    # Retrieve mandatory user-defined parameters
    project_key = get_recipe_config().get('project_key')
 
    # Attempt to get the project object by its key
    project = client.get_project(project_key)
    # Get the summary of the project
    project_summary = project.get_summary()
    project_summary_json = json.dumps(project_summary, indent=4)
    # print("Project Summary JSON:", project_summary_json)
    # Get the output folder name
    output_folder_name = get_output_names_for_role('main_output')[0]
    # print("Output Folder Name:", output_folder_name)
    # Get the output folder object
    output_folder = dataiku.Folder(output_folder_name)
    # print("Output Folder Object:", output_folder)
    # Define the JSON file name
    json_file_name = f"{project_key}_summary.json"
    # print("JSON File Name:", json_file_name)
    # Upload the JSON summary to the output folder
    output_folder.upload_stream(json_file_name, io.BytesIO(project_summary_json.encode('utf-8')))
    # print(f"Project summary has been saved to {json_file_name} in the output folder.")
    # Create Test_Dataiku.json
    test_data = [
        {
            "resourceType": "Community",
            "identifier": {
                "name": "Dataiku Community"
            }
        },
        {
            "resourceType": "Domain",
            "identifier": {
                "name": "Dataiku Asset Domain",
                "community": {
                    "name": "Dataiku Community"
                }
            },
            "type": {
                "name": "Business Asset Domain"
            }
        },
        {
            "resourceType": "Asset",
            "identifier": {
                "name": project_key,
                "domain": {
                    "name": "Dataiku Asset Domain",
                    "community": {
                        "name": "Dataiku Community"
                    }
                }
            },
            "type": {
                "name": "Project"
            },
            "attributes": {
                "Description": [
                    {
                        "value": "The project info."
                    }
                ]
            }
        }
    ]
    with open('Test_Dataiku.json', 'w') as f:
        data = json.dump(test_data, f)
        print("tested data", data)
    # Make HTTP request
    url = "https://expleo-sandbox.collibra.com/rest/2.0/import/json-job"
    payload = {}
    files=[('file',('Test_Dataiku.json',open('Test_Dataiku.json','rb'),'application/json'))]
    response = requests.request("POST", url, auth=HTTPBasicAuth('qateam', 'Lucid@123'), data=payload, files=files)
    print("Pushing summary into Collibra:- ", response.text)
except DataikuException as e:
    raise ValueError(f"Project not found: {project_key}. Detailed error: {str(e)}")
    print(f"Error: The project key '{project_key}' was not found. Detailed error: {str(e)}")
    
except Exception as e:
    print(f"An unexpected error occurred: {str(e)}")
   
   
print('''
===========================================\n
METADATA ENTITY\n
===========================================\n''')
# Connect to Dataiku project
client = dataiku.api_client()
# Get project handle
dataset_from_projectkey = client.get_project(project_key)
# Get list of datasets in the project
datasets = dataset_from_projectkey.list_datasets()
print("list of datasets:- ", datasets)
# Print metadata for each dataset
for dataset in datasets:
    print("Name:", dataset["name"])
    print("Type:", dataset["type"])
    print("formatType:", dataset["formatType"])
    print("Schema:", dataset["schema"]["columns"])
    print("Number of Columns:", len(dataset["schema"]["columns"]))
    print()
    
    
def get_extension(file_format):
    if file_format.lower() == "excel":
        return ".xlsx"
    elif file_format.lower() == "csv":
        return ".csv"
    else:
        return "Format not recognized"

print('''
===========================================\n
RECIPE ENTITY\n
===========================================\n''')

# List all recipes in the project
recipes = project.list_recipes()
print("--list of recipes---", recipes)
 
# Print the list of recipes
for recipe in recipes:
    print("--recipe name -----", recipe["name"])
    print("--recipe type-----", recipe["type"])
    # print("--recipe ref id-----", recipe["outputs"]["main_output"]["items"][0]["ref"])


print('''
===========================================\n
MANAGED FOLDERS ENTITY\n
===========================================\n''')
# List all managed folders in the project
managed_folders = project.list_managed_folders()
# print("---managed folders---", managed_folders)
 
# Print the names and IDs of the managed folders
for folder in managed_folders:
    print(f"Name: {folder['name']}, ID: {folder['id']}")


print('''
===========================================\n
CONNECTIONS ENTITY\n
===========================================\n''')
# Connections metadata info
connections = client.list_connections()
 
# Print metadata for each connection
# print("Connections Metadata:", connections)
 
for connection in connections:
    # Get connection details
    connection_name = connection
    connection_details = client.get_connection(connection_name).get_definition()
    print()
    print(f"Type1: {connection_details}")
    print(f"Connection Name: {connection_name}")
    print(f"Type: {connection_details['type']}")
    print(f"Creation Date: {connection_details.get('creationDate', 'N/A')}")
    print(f"Modification Date: {connection_details.get('modificationDate', 'N/A')}")
    print(f"Owner: {connection_details.get('owner', 'N/A')}")
    print(f"Params: {connection_details['params']}")
    print("----------")

    
print('''
===========================================\n
DATAIKU IMPORT INFORMATION\n
===========================================\n''')
dataiku_import1 = [
  {
    "resourceType": "Community",
    "identifier": {
      "name": "Dataiku Community"
    }
  },
  {
    "resourceType": "Domain",
    "identifier": {
      "name": "Dataiku Asset Domain",
      "community": {
        "name": "Dataiku Community"
      }
    },
    "type": {
      "name": "Business Asset Domain"
    },
    "attributes": {
      "Description": [
        {
          "value": "Represents a domain within the Dataiku community for managing business assets."
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": project_key,
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "Project"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Overview of the Dataiku Project"
        }
      ],
      "Name": [
        {
          "value": "DKU Tutorial First Plugin"
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007038:TARGET": [
        {
          "domain": {
            "name": "Dataiku Asset Domain",
            "community": {
              "name": "Dataiku Community"
            }
          },
          "name": dataset["name"]
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": dataset["name"],
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "Data Set"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007017:TARGET": [
        {
          "domain": {
            "name": "Dataiku Asset Domain",
            "community": {
              "name": "Dataiku Community"
            }
          },
          "name": dataset["name"] + get_extension(dataset["formatType"])
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": dataset["name"] + get_extension(dataset["formatType"]),
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "BI Data Entity"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007047:TARGET": [
        {
          "domain": {
            "name": "Dataiku Asset Domain",
            "community": {
              "name": "Dataiku Community"
            }
          },
          "name": dataset["schema"]["columns"][0]["name"]
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": dataset["name"] + get_extension(dataset["formatType"]),
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "BI Data Entity"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007047:TARGET": [
        {
          "domain": {
            "name": "Dataiku Asset Domain",
            "community": {
              "name": "Dataiku Community"
            }
          },
          "name": dataset["schema"]["columns"][1]["name"]
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": dataset["name"] + get_extension(dataset["formatType"]),
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "BI Data Entity"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007047:TARGET": [
        {
          "domain": {
            "name": "Dataiku Asset Domain",
            "community": {
              "name": "Dataiku Community"
            }
          },
          "name": dataset["schema"]["columns"][2]["name"]
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": dataset["schema"]["columns"][0]["name"],
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "BI Data Attribute"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007094:TARGET": [
        {
          "domain": {
            "name": "snowflake_nilesh2 > SNOWFLAKE_SAMPLE_DATA > TPCDS_SF100TCL",
            "community": {
              "name": "Snowflake_nilesh"
            }
          },
          "name": "snowflake_nilesh2>SNOWFLAKE_SAMPLE_DATA>TPCDS_SF100TCL>CUSTOMER_ADDRESS>CA_CITY(column)"
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": dataset["schema"]["columns"][1]["name"],
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "BI Data Attribute"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007094:TARGET": [
        {
          "domain": {
            "name": "snowflake_nilesh2 > SNOWFLAKE_SAMPLE_DATA > TPCDS_SF100TCL",
            "community": {
              "name": "Snowflake_nilesh"
            }
          },
          "name": "snowflake_nilesh2>SNOWFLAKE_SAMPLE_DATA>TPCDS_SF100TCL>CUSTOMER_ADDRESS>CA_ADDRESS_SK(column)"
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": dataset["schema"]["columns"][2]["name"],
      "domain": {
        "name": "Dataiku Asset Domain",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "BI Data Attribute"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007094:TARGET": [
        {
          "domain": {
            "name": "snowflake_nilesh2 > SNOWFLAKE_SAMPLE_DATA > TPCDS_SF100TCL",
            "community": {
              "name": "Snowflake_nilesh"
            }
          },
          "name": "snowflake_nilesh2>SNOWFLAKE_SAMPLE_DATA>TPCDS_SF100TCL>CUSTOMER_ADDRESS>CA_COUNTRY(column)"
        }
      ]
    }
  },
  {
    "resourceType": "Domain",
    "identifier": {
      "name": "Report Catalog",
      "community": {
        "name": "Dataiku Community"
      }
    },
    "type": {
      "name": "Report Catalog"
    },
    "attributes": {
      "Description": [
        {
          "value": "Represents a catalog within the Dataiku community for organizing reports."
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": "Dataiku Dashboard",
      "domain": {
        "name": "Report Catalog",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "Dataiku Dashboard"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007021:SOURCE": [
        {
          "domain": {
            "name": "Dataiku Asset Domain",
            "community": {
              "name": "Dataiku Community"
            }
          },
          "name": project_key
        }
      ]
    }
  },
  {
    "resourceType": "Asset",
    "identifier": {
      "name": "Dataiku report",
      "domain": {
        "name": "Report Catalog",
        "community": {
          "name": "Dataiku Community"
        }
      }
    },
    "type": {
      "name": "BI Report"
    },
    "status": {
      "name": "Accepted"
    },
    "attributes": {
      "Description": [
        {
          "value": "Users data used for analysis."
        }
      ]
    },
    "relations": {
      "00000000-0000-0000-0000-000000007021:SOURCE": [
        {
          "domain": {
            "name": "Report Catalog",
            "community": {
              "name": "Dataiku Community"
            }
          },
          "name": "Dataiku Dashboard"
        }
      ]
    }
  }
]

print('''
===========================================\n
POST INTO COLLIBRA INFORMATION\n
===========================================\n''')
with open('dataiku_import1.json', 'w') as f:
    data = json.dump(dataiku_import1, f)
    print("dataiku data imported", dataiku_import1)

# Make HTTP request
url = "https://expleo-sandbox.collibra.com/rest/2.0/import/json-job"
payload = {}
files=[('file',('dataiku_import1.json',open('dataiku_import1.json','rb'),'application/json'))]
response = requests.request("POST", url, auth=HTTPBasicAuth('qateam', 'Lucid@123'), data=payload, files=files)
print("Pushing summary posted into Collibra:- ", response.text)


print('''
===========================================\n
MODEL ENTITY\n
===========================================\n''')
# Get saved models in the project
saved_models = project.list_saved_models()

# Print information about saved models
for saved_model in saved_models:
    print("Saved Model Name:", saved_model)
    # print("Saved Model ID:", saved_model.id)
    # print("Saved Model Type:", saved_model.saved_model_type)
    # print("Saved Model Parameters:", saved_model.params)
    # Add more attributes as needed
    print("-----------------------------")
    print()
   

